self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "eda85a638dac0a1d866a",
    "url": "/static/js/main.eda85a63.chunk.js"
  },
  {
    "revision": "07d31d8c8d9564dfd8f9",
    "url": "/static/js/2.07d31d8c.chunk.js"
  },
  {
    "revision": "eda85a638dac0a1d866a",
    "url": "/static/css/main.3a5a7b40.chunk.css"
  },
  {
    "revision": "94ed32e8d40d49afe6fc85105e75a732",
    "url": "/index.html"
  }
];